#include "Conexión.h"

// Constructors/Destructors


Conexión::Conexión()
{
  initAttributes();
}

Conexión::~Conexión()
{
}

// Methods


// Accessor methods



// Other methods


void Conexión::initAttributes()
{
}

