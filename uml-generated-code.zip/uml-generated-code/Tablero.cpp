#include "Tablero.h"

// Constructors/Destructors


Tablero::Tablero()
{
  initAttributes();
}

Tablero::~Tablero()
{
}

// Methods


// Accessor methods



// Other methods


void Tablero::initAttributes()
{
  Casilla = 2;
}

