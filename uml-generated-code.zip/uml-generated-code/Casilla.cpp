#include "Casilla.h"

// Constructors/Destructors


Casilla::Casilla()
{
  initAttributes();
}

Casilla::~Casilla()
{
}

// Methods


// Accessor methods



// Other methods


void Casilla::initAttributes()
{
}

