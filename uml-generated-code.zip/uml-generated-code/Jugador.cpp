#include "Jugador.h"

// Constructors/Destructors


Jugador::Jugador()
{
  initAttributes();
}

Jugador::~Jugador()
{
}

// Methods


// Accessor methods



// Other methods


void Jugador::initAttributes()
{
  Puntuación = 0;
  Mejor_puntuación = 0;
}

