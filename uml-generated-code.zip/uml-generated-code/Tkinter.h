
#ifndef TKINTER_H
#define TKINTER_H

#include <string>


/// 
/// class Tkinter

class Tkinter
{
public:
  // Constructors/Destructors  



  /// 
  /// Empty Constructor
  Tkinter();

  /// 
  /// Empty Destructor
  virtual ~Tkinter();



  /// 
  void pack()
  {
  }


  /// 
  void grid()
  {
  }


  /// 
  void place()
  {
  }


};

#endif // TKINTER_H
