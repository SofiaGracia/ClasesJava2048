#include "Casilla_Comodin.h"

// Constructors/Destructors


Casilla_Comodin::Casilla_Comodin()
{
  initAttributes();
}

Casilla_Comodin::~Casilla_Comodin()
{
}

// Methods


// Accessor methods



// Other methods


void Casilla_Comodin::initAttributes()
{
  Color = Azul;
}

