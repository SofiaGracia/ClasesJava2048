#include "Partida.h"

// Constructors/Destructors


Partida::Partida()
{
  initAttributes();
}

Partida::~Partida()
{
}

// Methods


// Accessor methods



// Other methods


void Partida::initAttributes()
{
}

